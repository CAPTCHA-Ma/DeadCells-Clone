#pragma once
#include "cocos2d.h"

class StartMenu : public cocos2d::Scene
{
public:

    virtual bool init() override;

    CREATE_FUNC(StartMenu);

};