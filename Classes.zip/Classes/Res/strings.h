#pragma once
#include "cocos2d.h"

std::string GetText(const std::string& txt);