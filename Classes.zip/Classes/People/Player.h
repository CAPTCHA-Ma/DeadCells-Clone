#ifndef __PLAYER_H__
#define __PLAYER_H__
#include "cocos2d.h"
#include <unordered_map>
#include "Weapon.h" 
#include "FlyingObject.h"
#include "Arrow.h"
#include "Bomb.h"
struct StateConfig
{
    bool canBeInterrupted;
    int priority;
    bool loop;
};

enum class ActionState 
{
    idle,
    walk,
    run,        // ����
    rollStart,
    jumpDown,//
    jumpUp,
    crouch,     // �¶�
    dead,
    climbing,
    climbedge,
    hanging,

    atkA,   // ͽ�ֹ��� (��ͨ�ù���)
    atkB,

    atkBackStabber,


    AtkBaseballBatA,
    AtkBaseballBatB,
    AtkBaseballBatC,
    AtkBaseballBatD,
    AtkBaseballBatE,


    atkBroadSwordA,
    atkBroadSwordB,
    atkBroadSwordC,


    AtkOvenAxeA,
    AtkOvenAxeB,
    AtkOvenAxeC,

    AtkcloseCombatBow,
    AtkdualBow,
    crossbowShoot,

    blockEndLightningShield,
    blockEndParryShield,

    lethalHit,
    lethalFall,
    lethalSlam,

};

static std::unordered_map<ActionState, StateConfig> StateTable =
{//                     �ܷ񱻴�� ���ȼ�����Խ�����ȼ�Խ��   �����Ƿ�ѭ������
    { ActionState::idle,                                    { true,  0, true  } },
    { ActionState::walk,                                    { true,  1, true  } },
    { ActionState::run,                                     { true,  1, true  } },
    { ActionState::rollStart,                               { true,  2, false } },
    { ActionState::jumpDown,                                { true, 97, true } },
    { ActionState::jumpUp,                                  { true,  2, false } },
    { ActionState::crouch,                                  { true,  1, true } },
    { ActionState::dead,                                    { true,  100, false }},
	{ ActionState::climbing,                                 { true,  99, true  } },
	{ ActionState::climbedge,                               { true,  99, false  } },
	{ ActionState::hanging,                                 { true,  98, false  } },

    //����
    { ActionState::atkA,                                    { true, 3, false } },
    { ActionState::atkB,                                    { true, 3, false } },


    { ActionState::atkBackStabber,                          { true, 3, false } },

    { ActionState::AtkBaseballBatA,                         { true, 3, false } },
    { ActionState::AtkBaseballBatB,                         { true, 3, false } },
    { ActionState::AtkBaseballBatC,                         { true, 3, false } },
    { ActionState::AtkBaseballBatD,                         { true, 3, false } },
    { ActionState::AtkBaseballBatE,                         { true, 3, false } },


    { ActionState::atkBroadSwordA,                          { true, 3, false } },
    { ActionState::atkBroadSwordB,                          { true, 3, false } },
    { ActionState::atkBroadSwordC,                          { true, 3, false } },

    { ActionState::AtkOvenAxeA,                             { true, 3, false } },
    { ActionState::AtkOvenAxeB,                             { true, 3, false } },
    { ActionState::AtkOvenAxeC,                             { true, 3, false } },

    { ActionState::AtkcloseCombatBow,                       { true, 3, false } },
    { ActionState::AtkdualBow,                              { true, 3, false } },
    { ActionState::crossbowShoot,                           { true, 3, false } },

    { ActionState::blockEndLightningShield,                 { true, 3, false } },
    { ActionState::blockEndParryShield,                     { true, 3, false } },

    { ActionState::lethalHit,                               { true, 30, false } },
    { ActionState::lethalFall,                              { true, 99, false } },
    { ActionState::lethalSlam,                              { false, 99, false } },
};

class Player : public cocos2d::Sprite
{
public:

    CREATE_FUNC(Player);
    bool Player::init() override;
    void changeDirection(MoveDirection dir);
	void giveVelocityX(float speed);
	void giveVelocityY(float speed);
	void set0VelocityX();
	void set0VelocityY();
    bool isOnGround() const;
    bool isLethalState() const { return _state == ActionState::lethalHit || _state == ActionState::lethalFall || _state == ActionState::lethalSlam; };
	void update(float dt);

    //����
    void idle();
    void walk();
    void run();
    void rollStart();
    void jumpUp();
    void jumpDown();
    void crouch();
	void hanging();
    void climbing();
    void climbedge();
    void AtkcloseCombatBow();
    void AtkdualBow();
    void crossbowShoot();
    void changeStateByWeapon(Weapon* weapon);
    void whenOnAttackKey(Weapon* w);
    void actionWhenEnding(ActionState state);
    void dead();
    void lethalHit();

    //����
    void changeState(ActionState newState);
	bool whetherCanChangeToNewState(ActionState newState) const;
    void playAnimation(ActionState state, bool loop);

	//����������ϵͳ
    void getWeapon(Weapon* w);
    void struck(float attackPower);
    void shootArrow();
    void throwBomb();
    bool _invincible = false;


protected:
	CC_SYNTHESIZE(BasicAttributes, _originalAttributes, OriginalAttributes);//��ʼ����ֻ��ȼ��й�
	CC_SYNTHESIZE(BasicAttributes, _finalAttributes, FinalAttributes);//����������װ���й�

	float _runSpeed; // ˮƽ�ƶ��ٶ�
	float _rollSpeed; // �����ٶ�
	float _jumpSpeed; // ��Ծ���ٶ�
	float _climbSpeed; // �����ٶ�
    ActionState _state;
    MoveDirection _direction;
    UpDownDirection _directionY = UpDownDirection::NONE;
    cocos2d::Vec2 _velocity; // ������Ծ���������ٶ�����
    Weapon* _mainWeapon;// ������
    Weapon* _subWeapon;// ������


    bool isAttackState(ActionState s) const;    //�ж��Ƿ�Ϊ����״̬
    bool _comboInput;                           // �Ƿ񻺴�������
    bool _canCombo;                             // ��ǰ�Ƿ���������
	int _comboStep = 0;                         // ��ǰ���в���


private:
    //����

   
    cocos2d::Animation* createAnim(const std::string& name, int frameCount, float delay) const;
    cocos2d::Animation* getAnimation(ActionState state);
    std::unordered_map<ActionState, cocos2d::Animation*> _animationCache;

	//�����ж�
    cocos2d::Node* _attackNode = nullptr;
    cocos2d::Node* _hurtNode = nullptr;

    void updatePhysicsBody(const cocos2d::Size& size, const cocos2d::Vec2& offset);
    void setupBodyProperties(cocos2d::PhysicsBody* body);
    void createNormalBody();
    void createRollBody();
    void startRollInvincible(float time);
    void createRollBox();
    void createAttackBox();
    void createShieldParryBox();
    void removeAttackBox();


};

#endif // __PLAYER_H__