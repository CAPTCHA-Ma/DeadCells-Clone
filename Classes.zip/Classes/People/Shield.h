#ifndef __SHIELD_H__
#define __SHIELD_H__

#include "Weapon.h"

class Shield : public Weapon
{
public:
	enum class ShieldType//����Ķ�����ö��
    {
        LightningShield,
        ParryShield
    };
    static Shield* create(int subTypeIndex);
    ShieldType getShieldType();
    Shield(ShieldType type);
private:
    ShieldType  _type;
};

#endif
