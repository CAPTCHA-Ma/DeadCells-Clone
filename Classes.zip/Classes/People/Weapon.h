#ifndef __WEAPON_H__
#define __WEAPON_H__

#include "cocos2d.h"
#include <string>
#include <map>
#include "People.h"

class Weapon
{
public:
    // �����ķ���
    enum class WeaponCategory
    {
        Sword,
        Shield,
        Bow
    };

    virtual ~Weapon() {}

    // ��̬��������
    static Weapon* create(WeaponCategory category);
    CC_SYNTHESIZE(WeaponCategory, _category, Category);
	CC_SYNTHESIZE(BasicAttributes, _weaponAttributes, WeaponAttributes);

protected:
    Weapon(WeaponCategory category);
};

#endif // __WEAPON_H__